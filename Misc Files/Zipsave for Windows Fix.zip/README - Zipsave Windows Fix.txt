##########################

Author: @brhkim
Date: 20-08-19
Title: Zipsave Windows Fix (documentation)

##########################

INTRODUCTION

##########################

Hello!

If you're reading this, you are likely a Stata-user on a Windows computer who is attempting to use the zipsave package. Unfortunately, the zipsave package relies on a number of command line functions that are not typically available in Windows computers by default, instead requiring the use of Linux or similar Bash-shell add-ons.

Because these can be a little complicated to install, I've created a quick fix that should do the trick and preserve most of the functionality of the package.



##########################

INSTALL INSTRUCTIONS

##########################

1. You will need to install the free 7zip compression program for Windows. At time of writing (20-08-19) you can find it here: https://www.7-zip.org/

2. Once the software is installed, you will need to drag and drop the contents of this archive (zipappend.ado, zipappend.hlp, zipmerge.ado, etc.) into the appropriate Stata custom ado folder and overwrite any versions of zipsave that exist there. By default, this is located in (C:/ado/plus/z). Note that Stata seems to store internet-installed packages by alphabetical letter, hence the file structure.

3. You will need to direct the custom ado-files to your 7z.exe file by adjusting each a-do file appropriately. By default, this filepath is (C:/Program Files/7-Zip/7z.exe). You can do so by opening each a-do file in any text editor (Notepad, Sublime Text, etc.).
	3a. For zipappend.ado, you will change the filepath on line 33 (shell "C:/Program Files/7-Zip/7z.exe" e "`zipfile'" -o"`tmpdat'" -y)
	3b. For zipmerge.ado, you will change the filepath on line 69 (shell "C:/Program Files/7-Zip/7z.exe" e "`zipfile'" -o"`tmpdat`fn''" -y)
	3c. For zipuse.ado, you will change the filepath on line 43 (shell "C:/Program Files/7-Zip/7z.exe" e "`zipfile'" -o"`tmpdat'" -y)
	3d. zipsave.ado requires no adjustments

4. That's it! You should now be able to just open up Stata and use the various zipsave commands as usual. Note that if you had Stata open while making these adjustments, you'll need to restart it. 

The last caveat is that the dtafile(dtafilename) option for each of the commands *will not work*. So this adjusted package can only work with zip archives in which only a single datafile exists; major limitation that hopefully still works for your use-case! I've adjusted the help-files accordingly.

If you'd like to uninstall this package, you can do so by removing the same files from the custom ado folder. You should be able to run ssc install zipsave to recover the original versions. You can uninstall 7zip through its uninstaller and the usual methods on Windows for uninstalling software.

Please let me know if you run into any issues! I'm @brhkim on Twitter and brhkim@gmail.com via email.

Best,
Brian